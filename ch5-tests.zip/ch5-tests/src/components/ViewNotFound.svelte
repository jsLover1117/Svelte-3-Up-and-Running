<h1 class="text-xl">Not found</h1>
<p>This page does not exist.</p>
<p><a href="#/" class="text-blue-600 underline">View all entries</a></p>
<p><a href="/add" use:link class="text-blue-600 underline">Add a new one</a></p>
<script>
import {link} from 'svelte-spa-router'
</script>