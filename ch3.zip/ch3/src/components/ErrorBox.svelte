<div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 my-2 mx-6" role="alert">
    <p class="font-bold">Error</p>
    <p>{err}</p>
</div>

<script>
export let err = ''
</script>
